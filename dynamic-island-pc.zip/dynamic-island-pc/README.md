# Dynamic Island PC

Une Dynamic Island pour Windows, construite avec Electron. Elle reprend les fonctionnalités de la version mobile (Android), sauf les Galaxy Buds.

Elle ne reste pas affichée en permanence :

1. Quand une tâche arrive, une **petite bulle noire descend** du haut de l’écran.
2. Elle devient une **petite pilule** et le reste **tant que la tâche dure**.
3. Quand il n’y a plus de tâche, la pilule **se retransforme en boule**.
4. La boule **remonte** et disparaît en haut de l’écran.

Un clic sur la pilule la déplie (boutons de contrôle), un nouveau clic la replie.
Si plusieurs tâches sont actives, la plus récente s’affiche ; quand elle se termine, la précédente reprend sa place.
Les clics passent à travers la fenêtre partout ailleurs, donc elle ne gêne pas les autres applications.

## Installation

Il faut [Node.js](https://nodejs.org) 18 ou plus récent.

```bash
git clone https://github.com/kouakoukarl2000-create/island-for-pc.git
cd island-for-pc
npm install
npm start
```

Une icône apparaît près de l’horloge. Clic droit dessus pour tous les réglages.

## Fonctionnalités

| Fonctionnalité | Comportement |
| --- | --- |
| Musique | Détectée automatiquement (Spotify, navigateur, lecteurs…). Pochette, équaliseur, précédent / lecture-pause / suivant. Disparaît 2,5 s après la pause. |
| Minuteur | Menu de l’icône ou API. Pause, +1 min, arrêt. Notification à la fin. |
| Batterie | Animation au branchement du chargeur, « Chargée » à 100 %, alerte « Batterie faible » à 20, 10 et 5 %. |
| Volume | Pilule avec niveau à chaque changement de volume, icône muet. |
| Micro / caméra | Point orange (micro) ou vert (caméra) à côté de l’île quand une application les utilise. |
| Déverrouillage | Cadenas qui s’ouvre quand la session Windows est déverrouillée. |
| Notification / progression | Déclenchées par l’API locale (copie de fichier, téléchargement…). |
| Réglages | Taille, distance du haut, position gauche / centre / droite, options, lancement au démarrage. |

## Ce qui n’existe pas sur PC

- **Galaxy Buds2 Pro** : exclu à votre demande.
- **Appels et « raccrocher »**, **navigation GPS**, **enregistrement d’appel** : ces fonctions viennent du téléphone, Windows n’y a pas accès.
- **Minuteur de l’appli Horloge** et **bulle secondaire** (deux tâches affichées en même temps) : non reproduits.

## Piloter l’île depuis un autre programme

L’application écoute sur `127.0.0.1:41234` (uniquement cette machine). Exemples PowerShell :

```powershell
# Notification
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:41234/task -ContentType 'application/json' `
  -Body '{"type":"notif","title":"Koffi","text":"On se voit à 18 h ?"}'

# Minuteur de 90 secondes
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:41234/task -ContentType 'application/json' `
  -Body '{"type":"timer","seconds":90}'

# Progression : renvoyer la requête avec une nouvelle valeur pour la mettre à jour
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:41234/task -ContentType 'application/json' `
  -Body '{"type":"progress","label":"Copie en cours","value":40}'

# Terminer la tâche en cours
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:41234/end
```

Types acceptés : `timer`, `notif`, `progress`, `hud`, `charge`, `unlock`.

## Créer l’installeur Windows

```bash
npm run dist
```

L’installeur `.exe` est créé dans le dossier `dist/`.

## Publier une nouvelle version sur GitHub

Créez un tag : GitHub Actions construit l’`.exe` et l’ajoute à la release.

```bash
git tag v1.1.0
git push origin v1.1.0
```

## Structure

```
src/main.js        fenêtre transparente, icône, réglages, API locale, surveillance Windows
src/preload.js     pont sécurisé entre main et renderer
src/renderer.js    animations (bulle → pilule → boule) et tâches
src/ps/media.ps1   musique en cours et boutons (Windows Media Transport Controls)
src/ps/privacy.ps1 micro / caméra utilisés
src/ps/volume.ps1  niveau du volume
src/index.html, src/style.css
assets/icon-pc.png, icon-pc.ico   icône de la version PC
assets/mobile/                    icônes de la version mobile
.github/workflows/build.yml       build Windows automatique
```

## Licence

MIT
