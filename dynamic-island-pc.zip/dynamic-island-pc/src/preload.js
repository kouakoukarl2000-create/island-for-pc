const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('island', {
  onEvent: (cb) => ipcRenderer.on('ev', (_e, data) => cb(data)),
  setInteractive: (value) => ipcRenderer.send('interactive', !!value),
  media: (cmd) => ipcRenderer.send('media', String(cmd)),
  getSettings: () => ipcRenderer.invoke('settings')
});
