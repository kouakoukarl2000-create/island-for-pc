const isl = document.getElementById('isl');
const inner = document.getElementById('in');
const dots = document.getElementById('dots');
const dotMic = document.getElementById('dm');
const dotCam = document.getElementById('dc');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const B = 16;        // taille de la boule
const MAXW = 520;    // largeur max de la pilule

let S = { scale: 100, top: 8, pos: 0, dots: true, unlock: true };
let priv = { mic: false, cam: false };
let curW = B;

const persist = new Map();   // tâches qui durent : music, timer, progress
let flash = null;            // tâche passagère : notif, hud, charge, unlock
let seq = 0;
let shown = null, active = false, busy = false, expanded = false, lastKey = '';

/* ---------- Outils ---------- */
const esc = (v, n = 80) => String(v == null ? '' : v).slice(0, n).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => Math.floor(n / 60) + ':' + String(n % 60).padStart(2, '0');
const clamp = (v) => Math.max(0, Math.min(100, Math.round(+v || 0)));
const EQ = '<div class="eq"><i></i><i></i><i></i></div>';
const COV = '<div class="cov"></div>';
const AV = (t) => '<div class="av">' + esc(String(t || '?').charAt(0).toUpperCase(), 2) + '</div>';
const barHtml = (p, color) => '<div class="bar"><b style="width:' + p + '%;' + (color ? 'background:' + color : '') + '"></b></div>';
const left = (s) => s.paused ? Math.ceil(s.leftMs / 1000) : Math.max(0, Math.ceil((s.end - Date.now()) / 1000));
const act = (name, label, cls) => '<span class="' + (cls || 'cb') + '" data-act="' + name + '">' + label + '</span>';
const volEmoji = (v, m) => m || v === 0 ? '🔇' : v < 34 ? '🔈' : v < 67 ? '🔉' : '🔊';

/* ---------- Les types de tâches ---------- */
const defs = {
  music: {
    persist: true,
    init: (d) => ({ title: d.title || '', artist: d.artist || '', playing: d.playing !== false }),
    compact: (s) => [COV, s.playing ? EQ : '<span class="sub">⏸</span>'],
    full: (s) => '<div class="cov big"></div><div><div class="tx">' + esc(s.title || 'Lecture en cours') + '</div><div class="sub tx">' + esc(s.artist) + '</div></div>' +
      '<div class="ctl">' + act('prev', '⏮') + act('toggle', s.playing ? '⏸' : '▶') + act('next', '⏭') + '</div>'
  },
  timer: {
    persist: true,
    init: (d) => ({ end: Date.now() + Math.max(1, Math.min(86400, +d.seconds || 60)) * 1000, paused: false, leftMs: 0 }),
    compact: (s) => ['<span class="org">⏱</span>', '<span class="org num">' + fmt(left(s)) + '</span>'],
    full: (s) => '<span class="org">⏱</span><span class="big org num">' + fmt(left(s)) + '</span>' +
      '<div class="ctl">' + act('timer-pause', s.paused ? '▶' : '⏸') + act('timer-add', '+1 min', 'chip') + act('timer-stop', 'Arrêter', 'chip stop') + '</div>'
  },
  progress: {
    persist: true,
    init: (d) => ({ p: clamp(d.value), label: d.label || 'Progression' }),
    compact: (s) => ['<div class="ring" style="background:conic-gradient(#0a84ff ' + s.p * 3.6 + 'deg,#2a2d34 0)"></div>', '<span class="num">' + s.p + ' %</span>'],
    full: (s) => '<span class="tx">' + esc(s.label) + '</span>' + barHtml(s.p) + '<span class="sub num">' + s.p + ' %</span>'
  },
  notif: {
    ms: 4000,
    init: (d) => ({ title: String(d.title || 'Notification'), text: d.text || '' }),
    compact: (s) => [AV(s.title), '<span class="sub">' + esc(s.title, 12) + '</span>'],
    full: (s) => AV(s.title) + '<div class="tx"><span>' + esc(s.title) + '</span> <span class="sub">' + esc(s.text) + '</span></div>'
  },
  hud: {
    ms: 2400,
    init: (d) => ({ emoji: d.emoji || '🔊', text: d.text || '', level: clamp(d.level) }),
    compact: (s) => ['<span class="emo">' + esc(s.emoji, 4) + '</span>', '<span class="num">' + s.level + ' %</span>'],
    full: (s) => '<span class="emo">' + esc(s.emoji, 4) + '</span><span>' + esc(s.text) + '</span>' + barHtml(s.level) + '<span class="sub num">' + s.level + ' %</span>'
  },
  charge: {
    ms: 3000,
    init: (d) => {
      const level = clamp(d.level), plugged = !!d.plugged;
      const color = plugged ? (level >= 80 ? '#30d158' : level >= 30 ? '#30d158' : '#ff9f0a') : '#ff453a';
      const label = plugged ? (level >= 100 ? 'Chargée' : 'En charge') : 'Batterie faible';
      return { level, plugged, color, label, ms: plugged ? 3000 : 4500 };
    },
    compact: (s) => ['<span class="' + (s.plugged ? 'grn' : 'red pulse') + '">' + (s.plugged ? '⚡' : '⚠') + '</span>', '<span class="num" style="color:' + s.color + '">' + s.level + ' %</span>'],
    full: (s) => '<span class="' + (s.plugged ? 'grn' : 'red pulse') + '">' + (s.plugged ? '⚡' : '⚠') + '</span><span>' + s.label + '</span>' + barHtml(s.level, s.color) + '<span class="num" style="color:' + s.color + '">' + s.level + ' %</span>'
  },
  unlock: {
    ms: 1900,
    init: () => ({ open: false }),
    compact: (s) => ['<span class="emo">' + (s.open ? '🔓' : '🔒') + '</span>', s.open ? '<span class="grn">✓</span>' : '<span class="sub">…</span>'],
    full: (s) => '<span class="emo">' + (s.open ? '🔓' : '🔒') + '</span><span>Déverrouillé</span>' + (s.open ? '<span class="grn">✓</span>' : '')
  }
};

/* ---------- Gestion des tâches ---------- */
const mk = (type, d) => ({ type, def: defs[type], s: defs[type].init(d), seq: ++seq });

function top() {
  if (flash) return flash;
  let best = null;
  for (const e of persist.values()) if (!best || e.seq > best.seq) best = e;
  return best;
}

function upsert(type, patch) {
  const e = persist.get(type);
  if (e) Object.assign(e.s, patch);
  else persist.set(type, mk(type, patch));
  refresh();
}

function endPersist(type) { persist.delete(type); refresh(); }

function endTop() {
  if (flash) flash = null;
  else { const e = top(); if (e) persist.delete(e.type); }
  refresh();
}

function onTask(d) {
  if (!d || !defs[d.type]) return;
  const type = d.type;
  if (type === 'progress') {
    const e = persist.get('progress');
    const p = clamp(d.value);
    if (e) {
      e.s.p = p;
      if (d.label) e.s.label = String(d.label);
      if (p >= 100) { persist.delete('progress'); }
      refresh();
    } else if (p < 100) {
      persist.set('progress', mk('progress', d));
      refresh();
    }
    return;
  }
  if (type === 'timer') { persist.set('timer', mk('timer', d)); refresh(); return; }
  if (type === 'hud' && flash && flash.type === 'hud') {
    Object.assign(flash.s, defs.hud.init(d));
    flash.until = Date.now() + defs.hud.ms;
    refresh();
    return;
  }
  const e = mk(type, d);
  e.until = Date.now() + (d.ms > 0 ? Math.min(+d.ms, 30000) : e.s.ms || e.def.ms);
  flash = e;
  if (type === 'unlock') setTimeout(() => { e.s.open = true; refresh(); }, 380);
  refresh();
}

/* ---------- Affichage : bulle → pilule → boule → remonte ---------- */
function size(w, h) {
  curW = w;
  isl.style.width = w + 'px';
  isl.style.height = h + 'px';
  positionDots();
}

function positionDots() {
  const k = S.scale / 100;
  const half = (active ? curW : 0) / 2;
  dots.style.left = 'calc(50% + ' + (S.pos + (half + 14) * k) + 'px)';
  dots.style.top = (S.top + 3 * k) + 'px';
  dots.style.transform = 'scale(' + k + ')';
}

function renderNow() {
  const e = shown;
  if (!e) return;
  let html;
  if (expanded) html = e.def.full(e.s);
  else { const c = e.def.compact(e.s); html = '<div class="cmp"><div>' + c[0] + '</div><div>' + c[1] + '</div></div>'; }
  const key = (expanded ? 'F' : 'C') + html;
  if (key === lastKey) return;
  lastKey = key;
  inner.innerHTML = html;
  const pad = expanded ? 44 : 26;
  size(Math.min(inner.offsetWidth + pad, MAXW), Math.max(inner.offsetHeight + (expanded ? 26 : 12), 34));
}

function refresh() {
  if (busy) return;
  const e = top();
  if (!e) { if (active) closeIsland(); return; }
  if (!active) openIsland(e);
  else if (e !== shown) swapTo(e);
  else renderNow();
}

// 1. la bulle descend  2. elle devient une petite pilule pendant la tâche
async function openIsland(e) {
  busy = true; active = true; shown = e; expanded = false; lastKey = '';
  size(B, B);
  inner.style.opacity = 0;
  isl.classList.remove('up');
  void isl.offsetWidth;
  isl.classList.add('on');
  await sleep(550);
  renderNow();
  isl.classList.add('live');
  await sleep(200);
  inner.style.opacity = 1;
  busy = false;
  refresh();
}

// Une autre tâche prend la place : la pilule change de contenu sans repartir
async function swapTo(e) {
  busy = true; shown = e; expanded = false; lastKey = '';
  isl.classList.remove('up');
  isl.classList.add('on');
  inner.style.opacity = 0;
  await sleep(160);
  renderNow();
  isl.classList.add('live');
  await sleep(150);
  inner.style.opacity = 1;
  busy = false;
  refresh();
}

// 3. plus de tâche : la pilule redevient une boule  4. la boule remonte
async function closeIsland() {
  busy = true;
  isl.classList.remove('live');
  window.island.setInteractive(false);
  const stop = () => { busy = false; refresh(); };
  await sleep(450); if (top()) return stop();
  inner.style.opacity = 0;
  await sleep(200); if (top()) return stop();
  expanded = false; lastKey = '';
  size(B, B);
  await sleep(600); if (top()) return stop();
  isl.classList.add('up');
  isl.classList.remove('on');
  await sleep(650); if (top()) return stop();
  active = false; shown = null; busy = false;
  positionDots();
  refresh();
}

/* ---------- Interactions ---------- */
isl.addEventListener('click', async () => {
  if (!shown || busy || !isl.classList.contains('live')) return;
  busy = true;
  inner.style.opacity = 0;
  await sleep(130);
  expanded = !expanded; lastKey = '';
  renderNow();
  await sleep(150);
  inner.style.opacity = 1;
  busy = false;
  refresh();
});

inner.addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-act]');
  if (!b) return;
  ev.stopPropagation();
  const a = b.dataset.act;
  if (a === 'prev' || a === 'next' || a === 'toggle') { window.island.media(a); return; }
  const t = persist.get('timer');
  if (!t) return;
  if (a === 'timer-pause') {
    if (t.s.paused) { t.s.end = Date.now() + t.s.leftMs; t.s.paused = false; }
    else { t.s.leftMs = Math.max(0, t.s.end - Date.now()); t.s.paused = true; }
  } else if (a === 'timer-add') {
    if (t.s.paused) t.s.leftMs += 60000; else t.s.end += 60000;
  } else if (a === 'timer-stop') {
    persist.delete('timer');
  }
  refresh();
});

isl.addEventListener('mouseenter', () => window.island.setInteractive(true));
isl.addEventListener('mouseleave', () => window.island.setInteractive(false));

/* ---------- Horloge interne (minuteur, fin des tâches passagères) ---------- */
setInterval(() => {
  const now = Date.now();
  if (flash && now >= flash.until) { flash = null; refresh(); return; }
  const t = persist.get('timer');
  if (t && !t.s.paused && now >= t.s.end) {
    persist.delete('timer');
    onTask({ type: 'notif', title: 'Minuteur', text: 'Terminé', ms: 5000 });
    return;
  }
  refresh();
}, 250);

/* ---------- Événements venant de Windows ---------- */
let musicTimer = null;
function onMusic(d) {
  if (d.status === 'Playing') {
    clearTimeout(musicTimer); musicTimer = null;
    upsert('music', { title: d.title, artist: d.artist, playing: true });
  } else if (persist.has('music')) {
    persist.get('music').s.playing = false;
    refresh();
    if (!musicTimer) musicTimer = setTimeout(() => { musicTimer = null; endPersist('music'); }, 2500);
  }
}

let lastVol = null;
function onVolume(d) {
  const prev = lastVol;
  lastVol = d;
  if (d.init || !prev) return;
  onTask({ type: 'hud', emoji: volEmoji(d.v, d.m), text: d.m ? 'Muet' : 'Volume', level: d.m ? 0 : d.v });
}

function applyDots() {
  dotMic.classList.toggle('on', !!(S.dots && priv.mic));
  dotCam.classList.toggle('on', !!(S.dots && priv.cam));
}

function applySettings() {
  const r = document.documentElement.style;
  r.setProperty('--s', S.scale / 100);
  r.setProperty('--top', S.top + 'px');
  r.setProperty('--x', S.pos + 'px');
  positionDots();
  applyDots();
}

window.island.onEvent((d) => {
  if (!d) return;
  switch (d.kind) {
    case 'task': onTask(d); break;
    case 'end': endTop(); break;
    case 'settings': S = Object.assign(S, d.settings); applySettings(); break;
    case 'music': onMusic(d); break;
    case 'privacy': priv = { mic: !!d.mic, cam: !!d.cam }; applyDots(); break;
    case 'volume': onVolume(d); break;
    case 'unlock': if (S.unlock) onTask({ type: 'unlock' }); break;
  }
});

window.island.getSettings().then((s) => { S = Object.assign(S, s); applySettings(); }).catch(() => {});
applySettings();

/* ---------- Batterie : branchement et batterie faible ---------- */
if (navigator.getBattery) {
  navigator.getBattery().then((b) => {
    const thresholds = [20, 10, 5];
    let warned = 100;
    b.addEventListener('chargingchange', () => {
      const level = Math.round(b.level * 100);
      if (b.charging) warned = 100;
      onTask({ type: 'charge', level, plugged: b.charging });
    });
    b.addEventListener('levelchange', () => {
      const level = Math.round(b.level * 100);
      if (b.charging) {
        if (level >= 100) onTask({ type: 'charge', level, plugged: true });
        return;
      }
      const t = thresholds.find((x) => level <= x && warned > x);
      if (t) { warned = t; onTask({ type: 'charge', level, plugged: false }); }
    });
    const start = Math.round(b.level * 100);
    warned = b.charging ? 100 : (thresholds.find((x) => start <= x) || 100);
  }).catch(() => {});
}
