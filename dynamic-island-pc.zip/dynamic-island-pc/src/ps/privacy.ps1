[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$base = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore'
function InUse([string]$cap) {
  $root = Join-Path $base $cap
  if (-not (Test-Path $root)) { return $false }
  $keys = @(Get-Item $root) + @(Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue)
  foreach ($k in $keys) {
    $start = $k.GetValue('LastUsedTimeStart')
    $stop = $k.GetValue('LastUsedTimeStop')
    if ($null -ne $start -and $null -ne $stop -and $start -gt 0 -and $stop -eq 0) { return $true }
  }
  return $false
}
$last = ''
while ($true) {
  try {
    $o = @{ mic = (InUse 'microphone'); cam = (InUse 'webcam') }
    $j = $o | ConvertTo-Json -Compress
    if ($j -ne $last) { $last = $j; [Console]::Out.WriteLine($j); [Console]::Out.Flush() }
  } catch { }
  Start-Sleep -Milliseconds 1500
}
