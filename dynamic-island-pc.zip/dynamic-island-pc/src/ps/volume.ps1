[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
  int f(); int g(); int h(); int i(); int j(); int k();
  int GetMasterVolumeLevelScalar(out float pfLevel);
  int l(); int m(); int n(); int o();
  int p();
  int GetMute(out bool pbMute);
}

[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
  int Activate(ref Guid id, int clsCtx, IntPtr activationParams, out IAudioEndpointVolume aev);
}

[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
  int f();
  int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
}

[ComImport, Guid("BCDE0395-E52F-46C0-8E3B-E31763A9AA95")]
class MMDeviceEnumeratorComObject { }

public class AudioVol {
  static IAudioEndpointVolume Get() {
    var en = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
    IMMDevice dev;
    en.GetDefaultAudioEndpoint(0, 1, out dev);
    Guid iid = typeof(IAudioEndpointVolume).GUID;
    IAudioEndpointVolume v;
    dev.Activate(ref iid, 23, IntPtr.Zero, out v);
    return v;
  }
  public static int Level() { float f; Get().GetMasterVolumeLevelScalar(out f); return (int)Math.Round(f * 100); }
  public static bool Muted() { bool m; Get().GetMute(out m); return m; }
}
'@

$first = $true
$last = ''
while ($true) {
  try {
    $l = [AudioVol]::Level()
    $m = [AudioVol]::Muted()
    $key = "$l-$m"
    if ($key -ne $last) {
      $last = $key
      $j = '{"v":' + $l + ',"m":' + $m.ToString().ToLower() + ',"init":' + $first.ToString().ToLower() + '}'
      [Console]::Out.WriteLine($j); [Console]::Out.Flush()
      $first = $false
    }
  } catch { }
  Start-Sleep -Milliseconds 250
}
