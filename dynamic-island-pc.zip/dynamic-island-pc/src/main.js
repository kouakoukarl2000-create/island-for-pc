const { app, BrowserWindow, Tray, Menu, screen, ipcMain, nativeImage, powerMonitor } = require('electron');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const WIN_W = 1200;
const WIN_H = 240;
const API_PORT = 41234;
const TYPES = ['timer', 'notif', 'progress', 'hud', 'charge', 'unlock'];
const MEDIA_CMDS = ['prev', 'toggle', 'next'];
const DEFAULTS = { scale: 100, top: 8, pos: 0, dots: true, unlock: true };

let win = null;
let tray = null;
let settings = { ...DEFAULTS };
const children = new Set();

if (!app.requestSingleInstanceLock()) app.quit();

/* ---------- Réglages (taille, position, options) ---------- */
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function loadSettings() {
  try {
    const j = JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
    for (const k of Object.keys(DEFAULTS)) if (typeof j[k] === typeof DEFAULTS[k]) settings[k] = j[k];
  } catch { /* premier lancement */ }
}

function setSetting(key, value) {
  settings[key] = value;
  try { fs.writeFileSync(settingsFile(), JSON.stringify(settings)); } catch { /* ignoré */ }
  send({ kind: 'settings', settings });
  tray.setContextMenu(buildMenu());
}

/* ---------- Fenêtre ---------- */
function send(data) {
  if (win && !win.isDestroyed()) win.webContents.send('ev', data);
}
const sendTask = (data) => send({ ...data, kind: 'task' });

function placeWindow() {
  if (!win) return;
  const { bounds } = screen.getPrimaryDisplay();
  win.setBounds({ x: Math.round(bounds.x + (bounds.width - WIN_W) / 2), y: bounds.y, width: WIN_W, height: WIN_H });
}

function createWindow() {
  win = new BrowserWindow({
    width: WIN_W, height: WIN_H, frame: false, transparent: true, resizable: false, movable: false,
    hasShadow: false, skipTaskbar: true, alwaysOnTop: true, focusable: false, show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setIgnoreMouseEvents(true, { forward: true });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => { placeWindow(); win.showInactive(); });
  win.webContents.once('did-finish-load', startMonitors);
}

// La fenêtre ne capte la souris que sur la pilule ; ailleurs les clics passent au travers.
ipcMain.on('interactive', (_e, value) => { if (win) win.setIgnoreMouseEvents(!value, { forward: true }); });
ipcMain.handle('settings', () => settings);
ipcMain.on('media', (_e, cmd) => {
  if (MEDIA_CMDS.includes(cmd)) runPs('media.ps1', ['-Mode', cmd], () => {});
});

/* ---------- Surveillance Windows (musique, micro/caméra, volume, verrouillage) ---------- */
function runPs(name, args, onJson) {
  if (process.platform !== 'win32') return null;
  try {
    const dir = path.join(app.getPath('userData'), 'ps');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, name);
    fs.writeFileSync(file, '\uFEFF' + fs.readFileSync(path.join(__dirname, 'ps', name), 'utf8'));
    const cp = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file, ...args], { windowsHide: true });
    let buf = '';
    cp.stdout.setEncoding('utf8');
    cp.stdout.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).replace(/^\uFEFF/, '').trim();
        buf = buf.slice(i + 1);
        if (line) { try { onJson(JSON.parse(line)); } catch { /* ligne ignorée */ } }
      }
    });
    cp.on('error', (e) => console.error(name, e.message));
    cp.on('exit', () => children.delete(cp));
    children.add(cp);
    return cp;
  } catch (e) {
    console.error(name, e.message);
    return null;
  }
}

function startMonitors() {
  runPs('media.ps1', ['-Mode', 'watch'], (o) =>
    send({ kind: 'music', status: String(o.status || ''), title: String(o.title || ''), artist: String(o.artist || '') }));
  runPs('privacy.ps1', [], (o) => send({ kind: 'privacy', mic: !!o.mic, cam: !!o.cam }));
  runPs('volume.ps1', [], (o) => send({ kind: 'volume', v: Number(o.v) || 0, m: !!o.m, init: !!o.init }));
  powerMonitor.on('unlock-screen', () => send({ kind: 'unlock' }));
}

app.on('before-quit', () => { for (const cp of children) { try { cp.kill(); } catch { /* ignoré */ } } });

/* ---------- Icône de la zone de notification ---------- */
function demoProgress() {
  let value = 0;
  const timer = setInterval(() => {
    value = Math.min(100, value + 4);
    sendTask({ type: 'progress', label: 'Copie en cours', value });
    if (value >= 100) clearInterval(timer);
  }, 250);
}

function buildMenu() {
  const radio = (label, key, val) => ({ label, type: 'radio', checked: settings[key] === val, click: () => setSetting(key, val) });
  return Menu.buildFromTemplate([
    { label: 'Minuteur', submenu: [1, 5, 10, 25, 60].map((m) => ({ label: m + ' min', click: () => sendTask({ type: 'timer', seconds: m * 60 }) })) },
    {
      label: 'Tester',
      submenu: [
        { label: 'Notification', click: () => sendTask({ type: 'notif', title: 'Koffi', text: 'On se voit à 18 h ?' }) },
        { label: 'Copie de fichier', click: demoProgress },
        { label: 'Volume', click: () => sendTask({ type: 'hud', emoji: '🔊', text: 'Volume', level: 60 }) },
        { label: 'Branchement du chargeur', click: () => sendTask({ type: 'charge', level: 84, plugged: true }) },
        { label: 'Batterie faible', click: () => sendTask({ type: 'charge', level: 15, plugged: false }) },
        { label: 'Déverrouillage', click: () => sendTask({ type: 'unlock' }) }
      ]
    },
    { label: 'Terminer la tâche en cours', click: () => send({ kind: 'end' }) },
    { type: 'separator' },
    { label: 'Taille', submenu: [80, 100, 120, 150].map((v) => radio(v + ' %', 'scale', v)) },
    { label: 'Distance du haut', submenu: [0, 8, 20, 40].map((v) => radio(v + ' px', 'top', v)) },
    { label: 'Position', submenu: [radio('Gauche', 'pos', -150), radio('Centre', 'pos', 0), radio('Droite', 'pos', 150)] },
    { type: 'separator' },
    { label: 'Points micro / caméra', type: 'checkbox', checked: settings.dots, click: (i) => setSetting('dots', i.checked) },
    { label: 'Animation au déverrouillage', type: 'checkbox', checked: settings.unlock, click: (i) => setSetting('unlock', i.checked) },
    {
      label: 'Lancer au démarrage de Windows', type: 'checkbox', checked: app.getLoginItemSettings().openAtLogin,
      click: (i) => app.setLoginItemSettings({ openAtLogin: i.checked })
    },
    { label: 'Quitter', click: () => app.quit() }
  ]);
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, '..', 'assets', 'icon-pc.png')).resize({ width: 16, height: 16 });
  tray = new Tray(icon);
  tray.setToolTip('Dynamic Island PC');
  tray.setContextMenu(buildMenu());
}

/* ---------- API locale (127.0.0.1 uniquement) ---------- */
function startApi() {
  const server = http.createServer((req, res) => {
    const reply = (code, body) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
    if (req.method !== 'POST' || (req.url !== '/task' && req.url !== '/end')) return reply(404, { error: 'not found' });
    let raw = '';
    req.on('data', (chunk) => { raw += chunk; if (raw.length > 10000) req.destroy(); });
    req.on('end', () => {
      if (req.url === '/end') { send({ kind: 'end' }); return reply(200, { ok: true }); }
      try {
        const data = JSON.parse(raw || '{}');
        if (!TYPES.includes(data.type)) return reply(400, { error: 'type invalide', types: TYPES });
        sendTask(data);
        reply(200, { ok: true });
      } catch {
        reply(400, { error: 'JSON invalide' });
      }
    });
  });
  server.on('error', (err) => console.error('API locale indisponible :', err.message));
  server.listen(API_PORT, '127.0.0.1');
}

app.whenReady().then(() => {
  loadSettings();
  createWindow();
  createTray();
  startApi();
  screen.on('display-metrics-changed', placeWindow);
});

app.on('second-instance', () => { if (win) win.showInactive(); });
app.on('window-all-closed', () => app.quit());
